package com.poly.thi_ph51025_2504

data class MonThi(
    val id: String,
    val hoTen: String,
    val monThi: String,
    val hinhAnh: String,
    val ngayThi: String,
    val caThi: String,
)
// b1